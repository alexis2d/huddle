<!DOCTYPE html>
<html>

<head>
<title>HUDDLE</title>
<meta name="viewport" content="initial-scale=1" />
<link href="css/style.css" rel="stylesheet">
</head>

<body>

<section id="section4">

<form  method="post" action="includes/register.php">

    <div>
     
        <p>
            <label> Name <br>
                <input type="text" id="name" name="name" minlength="2" required >
            </label>
        </p>
    
        <p>
            <label> Firstname <br>
                <input type="text" id="firstname"   name="firstname" minlength="2" required >
            </label>
        </p>
	
        
        <p>
            <label> Email <br>
                <input type="email"  id="mail" name="mail" required >
			</label>
        </p>
    
        <p>
            <label> Password <br> 
                <input type="password" id="password"  name="password" required minlength="8" maxlength="16" >
            </label>
        </p>
		
        <p>
            <label> Nickname <br>
	            <input type="text" id="nickname" name="nickname" required >
            </label>
        </p>

    </div>

    <p> <input type="submit" id="button-3" name="submit" value="Register" href="login.php"> <input id="button-3" type="reset"> </p> 

</form>

</section>

</body>
</html>