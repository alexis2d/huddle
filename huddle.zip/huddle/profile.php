<!DOCTYPE html>
<html>

<head>
<title>HUDDLE</title>
<meta name="viewport" content="initial-scale=1" />
<link href="css/style.css" rel="stylesheet">
</head>

<body>

<section id="section5">

    <p>
    <?php
        session_start();
        if($_SESSION['nickname'] !== ""){
            $user = $_SESSION['nickname'];
            echo "Hey $user, what's up?";
        }
    ?> 
    </p> <br>

    <a id="button-3" name="update" href="profile_update.php"> Update profile </a> 

</section>

</body>
</html>