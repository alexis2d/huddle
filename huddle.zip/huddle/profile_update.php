<!DOCTYPE html>
<html>

<head>
<title>HUDDLE</title>
<meta name="viewport" content="initial-scale=1" />
<link href="css/style.css" rel="stylesheet">
</head>

<body>

<section id="section7">

<form  method="post" action="includes/update.php">

    <div>

        <p>
            <label> Nickname <br>
	            <input type="text" id="nickname" name="nickname" required >
            </label>
        </p>

        <p>
            <label> Password <br> 
                <input type="password" id="password"  name="password" required minlength="8" maxlength="16" >
            </label>
        </p>

        <p>
            <label> New password <br> 
                <input type="password" id="newpassword"  name="newpassword" required minlength="8" maxlength="16" >
            </label>
        </p>

    </div>

    <p> <input type="submit" id="button-3" name="submit" value="Update" href="profile.php"> <input id="button-3" type="reset"> </p> 

</form>

</section>

</body>
</html>