<!DOCTYPE html>
<html>

<head>
<title>HUDDLE</title>
<meta name="viewport" content="initial-scale=1" />
<link href="css/style.css" rel="stylesheet">
</head>

<body>
    
    <header>
        
        <div id="entete">
            <img src="images/color_logo_transparent.png" alt="image encadrée" class="logo" href="home.php">

            <nav>
                <a class="button-1" href="login.php">Login</a>
            </nav>
        </div>

    </header>

    <div id="partDeux">

        <h3>Build The Community <br> Your Fans Will Love</h3>
        <p>Huddle re-imagines the way we build communities. You have a <br> voice, but so does your audience.
        Create connections with your <br> users as you engage in genuine discussion.</p>

        <a class="button-2" href="registration.php"> Get Started For Free</a>
            

        <img src="images/Group 10.png" alt="image encadrée" class="image1">
        <img src="images/Group 40.png" alt="image forme tablette" class="image2">

    </div>

    <section id="section1">
            <div>
                <h3>Grow Together</h3>
                <p>Generate meaningful discussions with you audience and <br>
                build a strong, loyal community. Think of the insightful <br>
            conversations you miss out on with a feedback form.</p>
            
            <img src="images/Group 20 Copy 3.png" alt="Image homme femme discuter" class="image3">
            </div>

    </section>
    <section id="section2">
        <div>
            <img src="images/grow_together.png" alt="Réunion autour d'une table" class="image4">
            <h3>Flowing Conversations</h3>
            <p>You wouldn't paginate a conversation in real life, so why do it <br>
            online? Our threads have just-in-time loading for a more <br>
        natural flow.</p>
        
       
        </div>

</section>

<section id="section3">
    <div>
        <h3>Your Users</h3>
        <p>It takes no time at all to integrate Huddle with you app's <br>
        authentification solution. This means, once signed in to your <br>
    app, your users can start chatting immediately.</p>
    
    <img src="images/grow_together.jpg" alt="Personnes entrain de discuter via un système de chatting" class="image5">
    </div>


</body>
</html>