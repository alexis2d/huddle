<!DOCTYPE html>
<html>

<head>
<title>HUDDLE</title>
<meta name="viewport" content="initial-scale=1" />
<link href="css/style.css" rel="stylesheet">
</head>

<body>

<section id="section6">

<form  method="post" action="includes/log.php">

    <div>
     
        <p>
            <label> Email <br>
                <input type="email"  id="mail" name="mail" required >
			</label>
        </p>
    
        <p>
            <label> Password <br> 
                <input type="password" id="password"  name="password" required minlength="8" maxlength="16" >
            </label>
        </p>

    </div>

    <p> <input type="submit" id="button-1" name="submit" value="Login" href="profile.php"> </p> 

</form>

</section>

</body>
</html>