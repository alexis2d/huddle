<?php

session_start();

            try {
	            $db = new PDO('mysql:host=localhost;dbname=huddle;charset=utf8','root','');
               }

            catch (Exception $e)
               {
               die('Erreur : ' . $e->getMessage());
               }


				include 'data.php';
				$pass = $_POST['password'];
				$mail = $_POST['mail'];
				$records = $db->prepare('SELECT nickname,email,password FROM  user WHERE email = :mail and password = :pass');
				$records->bindParam(':mail', $mail);
				$records->bindParam(':pass', $pass);
				$records->execute();
				$results = $records->fetch(PDO::FETCH_ASSOC);

				if (count($results) >0 && $pass == ($results['password'])){
					$_SESSION['mail'] = $results['mail'];
					$_SESSION['pass'] = $results['pass'];
					$_SESSION['nickname'] = $results['nickname'];
					header('location:../profile.php');
					exit;
				}else
				{
				header('location:../login.php');
}

?>