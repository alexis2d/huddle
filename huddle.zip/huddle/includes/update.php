<?php

include 'data.php';

try {
	$db = new PDO('mysql:host=localhost;dbname=huddle;charset=utf8','root','');
}

catch (Exception $e)
{
        die('Erreur : ' . $e->getMessage());
}

// Ecriture de la requête
$sqlQuery = 'UPDATE user SET password = :newpassword WHERE nickname = :nickname AND password = :password';

// Préparation
$registration = $db->prepare($sqlQuery);

// Exécution
$registration->execute([
    'nickname' => $_POST['nickname'], 
    'password' => $_POST['password'],
    'newpassword' => $_POST['newpassword'],
]);

?>