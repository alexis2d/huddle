<?php

    define('HOST', 'localhost');
    define('DB_Name','huddle');
    define('USER', 'root');
    define('PASS', '');
    try{
        $db = new PDO('mysql:host=' . HOST . ';dbname=' . DB_Name, USER, PASS, array());
        $db -> setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    } catch(PDOException $e) {
        echo $e;
    }

?>