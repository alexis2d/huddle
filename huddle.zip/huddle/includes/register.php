<?php

include 'data.php';

try {
	$db = new PDO('mysql:host=localhost;dbname=huddle;charset=utf8','root','');
}

catch (Exception $e)
{
        die('Erreur : ' . $e->getMessage());
}

$sqlQuery = 'INSERT INTO user(name, firstname, email, password, nickname) VALUES (:name, :firstname, :email, :password, :nickname)';

$registration = $db->prepare($sqlQuery);

$registration->execute([
    'name' => $_POST['name'],
    'firstname' => $_POST['firstname'],
    'email' => $_POST['mail'],
    'password' => $_POST['password'],
	'nickname' => $_POST['nickname'], 
]);

?>

<!DOCTYPE html>
<html>

<head>
<title>HUDDLE</title>
<meta name="viewport" content="initial-scale=1" />
<link href="../css/style.css" rel="stylesheet">
</head>

<body>

<section id="section8">

    <div>
     
        <p>
            You've been registered, please login.
        </p>

    </div>

    <a id="button-3" name="login" value="Login" href="../login.php">Login</a>

</form>

</section>

</body>
</html>